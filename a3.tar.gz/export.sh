#!/bin/bash
export BINDER_ADDRESS=$1
export BINDER_PORT=$2
